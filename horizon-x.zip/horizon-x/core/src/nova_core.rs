//! HORIZON-X core: tải game, loader, modpack, tham số JVM.
use anyhow::{anyhow, Result};
use futures::{stream, StreamExt};
use jni::objects::{JClass, JString};
use jni::sys::{jint, jstring};
use jni::JNIEnv;
use once_cell::sync::Lazy;
use serde_json::{json, Value};
use sha1::{Digest, Sha1};
use std::collections::VecDeque;
use std::io::Read;
use std::path::{Path, PathBuf};
use std::{fs, sync::Mutex};

static LOG: Lazy<Mutex<VecDeque<String>>> = Lazy::new(|| Mutex::new(VecDeque::new()));
static HTTP: Lazy<reqwest::Client> =
    Lazy::new(|| reqwest::Client::builder().user_agent("HorizonX/1.0").build().unwrap());
static RT: Lazy<tokio::runtime::Runtime> = Lazy::new(|| {
    tokio::runtime::Builder::new_multi_thread().worker_threads(4).enable_all().build().unwrap()
});

type Job = (String, PathBuf, Option<String>);

pub fn log(s: impl Into<String>) {
    let mut l = LOG.lock().unwrap();
    if l.len() > 500 { l.pop_front(); }
    l.push_back(s.into());
}
fn drain_log() -> String {
    LOG.lock().unwrap().drain(..).collect::<Vec<_>>().join("\n")
}
fn s(v: &Value) -> String { v.as_str().unwrap_or("").to_string() }
fn sha1_hex(b: &[u8]) -> String { format!("{:x}", Sha1::digest(b)) }
fn safe_join(base: &Path, rel: &str) -> Option<PathBuf> {
    if rel.contains("..") || rel.starts_with('/') || rel.starts_with('\\') { None } else { Some(base.join(rel)) }
}

async fn get_text(url: &str, key: Option<&str>) -> Result<String> {
    let mut r = HTTP.get(url);
    if let Some(k) = key { r = r.header("x-api-key", k); }
    Ok(r.send().await?.error_for_status()?.text().await?)
}
async fn get_json(url: &str) -> Result<Value> { Ok(serde_json::from_str(&get_text(url, None).await?)?) }

async fn download(url: &str, dest: &Path, sha1: Option<&str>) -> Result<()> {
    let want = sha1.map(|h| h.to_lowercase()).filter(|h| !h.is_empty());
    if dest.exists() {
        match &want {
            Some(h) => if sha1_hex(&fs::read(dest)?) == *h { return Ok(()); },
            None => return Ok(()),
        }
    }
    if let Some(p) = dest.parent() { fs::create_dir_all(p)?; }
    let mut last = anyhow!("download failed");
    for _ in 0..3 {
        match HTTP.get(url).send().await.and_then(|r| r.error_for_status()) {
            Ok(r) => match r.bytes().await {
                Ok(b) => {
                    if let Some(h) = &want {
                        if sha1_hex(&b) != *h { last = anyhow!("sha1 sai: {url}"); continue; }
                    }
                    let tmp = dest.with_extension("part");
                    fs::write(&tmp, &b)?;
                    fs::rename(&tmp, dest)?;
                    return Ok(());
                }
                Err(e) => last = e.into(),
            },
            Err(e) => last = e.into(),
        }
    }
    Err(last)
}

async fn download_all(jobs: Vec<Job>) -> Result<()> {
    let total = jobs.len();
    log(format!("Tải {total} tệp..."));
    let res: Vec<bool> = stream::iter(jobs)
        .map(|(u, p, h)| async move {
            match download(&u, &p, h.as_deref()).await {
                Ok(_) => true,
                Err(e) => { log(format!("LỖI {e}")); false }
            }
        })
        .buffer_unordered(16)
        .collect()
        .await;
    let bad = res.iter().filter(|x| !**x).count();
    if bad > 0 { return Err(anyhow!("{bad}/{total} tệp tải lỗi")); }
    log("Tải xong.");
    Ok(())
}

fn rule_ok(l: &Value) -> bool {
    match l.get("rules").and_then(|r| r.as_array()) {
        None => true,
        Some(rs) => {
            let mut ok = false;
            for r in rs {
                let os = r.get("os").and_then(|o| o["name"].as_str());
                if os.map_or(true, |n| n == "linux") { ok = r["action"] == "allow"; }
            }
            ok
        }
    }
}
fn maven_path(name: &str) -> String {
    let p: Vec<&str> = name.split(':').collect();
    format!("{}/{}/{}/{}-{}.jar", p[0].replace('.', "/"), p[1], p[2], p[1], p[2])
}
fn lib_jobs(libs: &Value, root: &Path) -> Vec<Job> {
    let mut out = vec![];
    for l in libs.as_array().cloned().unwrap_or_default() {
        let name = s(&l["name"]);
        // LWJGL được thay bằng bản Android do lớp bridge cung cấp.
        if !rule_ok(&l) || name.starts_with("org.lwjgl") || name.split(':').count() < 3 { continue; }
        let a = &l["downloads"]["artifact"];
        if let (Some(url), Some(path)) = (a["url"].as_str(), a["path"].as_str()) {
            out.push((url.to_string(), root.join("libraries").join(path), Some(s(&a["sha1"]))));
        } else if l.get("natives").is_none() {
            let mut base = l["url"].as_str().unwrap_or("https://libraries.minecraft.net/").to_string();
            if !base.ends_with('/') { base.push('/'); }
            let mp = maven_path(&name);
            out.push((format!("{base}{mp}"), root.join("libraries").join(&mp), None));
        }
    }
    out
}

pub async fn install_version(mc: &str, root: &Path) -> Result<i32> {
    log(format!("Lấy manifest {mc}..."));
    let m = get_json("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json").await?;
    let url = m["versions"].as_array().cloned().unwrap_or_default().iter()
        .find(|v| v["id"] == mc).map(|v| s(&v["url"]))
        .ok_or_else(|| anyhow!("Không có phiên bản {mc}"))?;
    let v = get_json(&url).await?;
    let vdir = root.join("versions").join(mc);
    fs::create_dir_all(&vdir)?;
    fs::write(vdir.join(format!("{mc}.json")), serde_json::to_vec(&v)?)?;
    let c = &v["downloads"]["client"];
    let mut jobs: Vec<Job> = vec![(s(&c["url"]), vdir.join(format!("{mc}.jar")), Some(s(&c["sha1"])))];
    jobs.extend(lib_jobs(&v["libraries"], root));
    let ai = &v["assetIndex"];
    let ip = root.join("assets/indexes").join(format!("{}.json", s(&ai["id"])));
    download(&s(&ai["url"]), &ip, Some(&s(&ai["sha1"]))).await?;
    let idx: Value = serde_json::from_slice(&fs::read(&ip)?)?;
    if let Some(objs) = idx["objects"].as_object() {
        for (_, o) in objs {
            let h = s(&o["hash"]);
            let p = &h[..2];
            jobs.push((format!("https://resources.download.minecraft.net/{p}/{h}"),
                root.join("assets/objects").join(p).join(&h), Some(h.clone())));
        }
    }
    download_all(jobs).await?;
    Ok(v["javaVersion"]["majorVersion"].as_i64().unwrap_or(8) as i32)
}

/// Fabric / Quilt. Trả về "id|mainClass". Forge/NeoForge cần chạy installer.jar bằng JVM.
pub async fn install_loader(mc: &str, kind: &str, root: &Path) -> Result<String> {
    let base = match kind {
        "fabric" => "https://meta.fabricmc.net/v2/versions/loader",
        "quilt" => "https://meta.quiltmc.org/v3/versions/loader",
        _ => return Err(anyhow!("{kind}: chạy installer.jar qua JVM (xem GameLauncher)")),
    };
    let l = get_json(&format!("{base}/{mc}")).await?;
    let lv = s(&l[0]["loader"]["version"]);
    let p = get_json(&format!("{base}/{mc}/{lv}/profile/json")).await?;
    let id = s(&p["id"]);
    let vdir = root.join("versions").join(&id);
    fs::create_dir_all(&vdir)?;
    fs::write(vdir.join(format!("{id}.json")), serde_json::to_vec(&p)?)?;
    download_all(lib_jobs(&p["libraries"], root)).await?;
    Ok(format!("{id}|{}", s(&p["mainClass"])))
}

fn extract(z: &mut zip::ZipArchive<fs::File>, prefixes: &[&str], dest: &Path) -> Result<()> {
    for i in 0..z.len() {
        let mut e = z.by_index(i)?;
        let name = e.name().to_string();
        for pre in prefixes {
            if let Some(rel) = name.strip_prefix(pre) {
                if rel.is_empty() || e.is_dir() { break; }
                if let Some(dst) = safe_join(dest, rel) {
                    if let Some(p) = dst.parent() { fs::create_dir_all(p)?; }
                    std::io::copy(&mut e, &mut fs::File::create(dst)?)?;
                }
                break;
            }
        }
    }
    Ok(())
}

async fn cf_file(pid: u64, fid: u64, key: &str) -> Result<(String, String)> {
    let t = get_text(&format!("https://api.curseforge.com/v1/mods/{pid}/files/{fid}"), Some(key)).await?;
    let d: Value = serde_json::from_str(&t)?;
    let name = s(&d["data"]["fileName"]);
    let url = d["data"]["downloadUrl"].as_str().map(String::from)
        .unwrap_or_else(|| format!("https://edge.forgecdn.net/files/{}/{}/{}", fid / 1000, fid % 1000, name));
    Ok((name, url))
}

/// .mrpack (Modrinth) hoặc .zip (CurseForge / ZIP thường). Trả JSON dependencies.
pub async fn install_modpack(path: &str, inst: &Path, cf_key: &str) -> Result<String> {
    fs::create_dir_all(inst)?;
    let mut z = zip::ZipArchive::new(fs::File::open(path)?)?;
    let names: Vec<String> = z.file_names().map(String::from).collect();
    if names.iter().any(|n| n == "modrinth.index.json") {
        let mut t = String::new();
        z.by_name("modrinth.index.json")?.read_to_string(&mut t)?;
        let idx: Value = serde_json::from_str(&t)?;
        log(format!("Modrinth pack: {}", s(&idx["name"])));
        let mut jobs: Vec<Job> = vec![];
        for f in idx["files"].as_array().cloned().unwrap_or_default() {
            if f["env"]["client"] == "unsupported" { continue; }
            if let Some(dst) = safe_join(inst, &s(&f["path"])) {
                jobs.push((s(&f["downloads"][0]), dst, Some(s(&f["hashes"]["sha1"]))));
            }
        }
        download_all(jobs).await?;
        extract(&mut z, &["overrides/", "client-overrides/"], inst)?;
        Ok(idx["dependencies"].to_string())
    } else if names.iter().any(|n| n == "manifest.json") {
        let mut t = String::new();
        z.by_name("manifest.json")?.read_to_string(&mut t)?;
        let m: Value = serde_json::from_str(&t)?;
        if cf_key.is_empty() { return Err(anyhow!("CurseForge cần API key (console.curseforge.com)")); }
        let files = m["files"].as_array().cloned().unwrap_or_default();
        let resolved: Vec<_> = stream::iter(files)
            .map(|f| async move {
                cf_file(f["projectID"].as_u64().unwrap_or(0), f["fileID"].as_u64().unwrap_or(0), cf_key).await
            })
            .buffer_unordered(8).collect().await;
        let mut jobs: Vec<Job> = vec![];
        for r in resolved {
            match r {
                Ok((n, u)) => if let Some(dst) = safe_join(&inst.join("mods"), &n) { jobs.push((u, dst, None)) },
                Err(e) => log(format!("LỖI CF: {e}")),
            }
        }
        download_all(jobs).await?;
        let ov = format!("{}/", m["overrides"].as_str().unwrap_or("overrides"));
        extract(&mut z, &[ov.as_str()], inst)?;
        Ok(json!({"minecraft": m["minecraft"]["version"], "loader": m["minecraft"]["modLoaders"][0]["id"]}).to_string())
    } else {
        extract(&mut z, &[""], inst)?;
        Ok("{}".into())
    }
}

/// Tham số JVM: RAM động + GC tối ưu cho ARM64.
pub fn jvm_args(java_major: i32, ram_mb: i32) -> String {
    let xmx = (ram_mb / 2).clamp(1024, 3584);
    let xms = xmx.min(512);
    let mut a = vec![
        format!("-Xms{xms}M"), format!("-Xmx{xmx}M"),
        "-XX:+UseG1GC".into(), "-XX:MaxGCPauseMillis=50".into(),
        "-XX:+ParallelRefProcEnabled".into(), "-XX:+DisableExplicitGC".into(),
        "-XX:ReservedCodeCacheSize=128m".into(), "-Xshare:auto".into(),
    ];
    if java_major >= 17 { a.push("-XX:+UseStringDeduplication".into()); }
    a.join("\n")
}

// ---------------- JNI ----------------
fn js(env: &mut JNIEnv, j: &JString) -> String { env.get_string(j).map(|x| x.into()).unwrap_or_default() }
fn out(env: &mut JNIEnv, v: String) -> jstring { env.new_string(v).unwrap().into_raw() }

#[no_mangle]
pub extern "system" fn Java_com_horizonx_launcher_NovaCore_installVersion(
    mut env: JNIEnv, _c: JClass, mc: JString, root: JString) -> jint {
    let (mc, root) = (js(&mut env, &mc), js(&mut env, &root));
    match RT.block_on(install_version(&mc, Path::new(&root))) {
        Ok(j) => j,
        Err(e) => { log(format!("LỖI: {e}")); -1 }
    }
}
#[no_mangle]
pub extern "system" fn Java_com_horizonx_launcher_NovaCore_installLoader(
    mut env: JNIEnv, _c: JClass, mc: JString, kind: JString, root: JString) -> jstring {
    let (mc, kind, root) = (js(&mut env, &mc), js(&mut env, &kind), js(&mut env, &root));
    let r = RT.block_on(install_loader(&mc, &kind, Path::new(&root))).unwrap_or_else(|e| format!("ERR:{e}"));
    out(&mut env, r)
}
#[no_mangle]
pub extern "system" fn Java_com_horizonx_launcher_NovaCore_installModpack(
    mut env: JNIEnv, _c: JClass, path: JString, inst: JString, key: JString) -> jstring {
    let (p, i, k) = (js(&mut env, &path), js(&mut env, &inst), js(&mut env, &key));
    let r = RT.block_on(install_modpack(&p, Path::new(&i), &k)).unwrap_or_else(|e| format!("ERR:{e}"));
    out(&mut env, r)
}
#[no_mangle]
pub extern "system" fn Java_com_horizonx_launcher_NovaCore_jvmArgs(
    mut env: JNIEnv, _c: JClass, java: jint, ram: jint) -> jstring {
    out(&mut env, jvm_args(java, ram))
}
#[no_mangle]
pub extern "system" fn Java_com_horizonx_launcher_NovaCore_pollLog(mut env: JNIEnv, _c: JClass) -> jstring {
    out(&mut env, drain_log())
}
