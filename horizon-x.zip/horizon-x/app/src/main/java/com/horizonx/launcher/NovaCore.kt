package com.horizonx.launcher

object NovaCore {
    init { System.loadLibrary("nova_core") }
    external fun installVersion(mc: String, root: String): Int          // trả Java major, -1 nếu lỗi
    external fun installLoader(mc: String, kind: String, root: String): String // "id|mainClass" hoặc "ERR:.."
    external fun installModpack(path: String, instDir: String, cfKey: String): String
    external fun jvmArgs(javaMajor: Int, ramMb: Int): String
    external fun pollLog(): String
}
