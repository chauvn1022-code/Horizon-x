package com.horizonx.launcher

import android.app.ActivityManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun LauncherScreen(ctx: Context) {
    val scope = rememberCoroutineScope()
    var version by remember { mutableStateOf("1.20.1") }
    var loader by remember { mutableStateOf("vanilla") }
    var cfKey by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Sẵn sàng") }
    var busy by remember { mutableStateOf(false) }
    val logs = remember { mutableStateListOf<String>() }
    val listState = rememberLazyListState()
    val root = remember { File(ctx.filesDir, "horizonx").apply { mkdirs() }.absolutePath }
    fun ramMb(): Int {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return (mi.totalMem / 1048576).toInt()
    }

    LaunchedEffect(Unit) {
        while (true) {
            val l = NovaCore.pollLog()
            if (l.isNotEmpty()) {
                logs.addAll(l.split("\n"))
                while (logs.size > 400) logs.removeAt(0)
                listState.scrollToItem(maxOf(0, logs.size - 1))
            }
            delay(300)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            busy = true; status = "Đang cài modpack..."
            val f = File(ctx.cacheDir, "pack.tmp")
            ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val r = NovaCore.installModpack(f.absolutePath, "$root/instances/pack", cfKey)
            status = if (r.startsWith("ERR")) r else "Modpack xong: $r"
            busy = false
        }
    }

    Column(Modifier.fillMaxSize().background(Color(0xFF0B0F14)).padding(16.dp).systemBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("HORIZON-X", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary)
        OutlinedTextField(version, { version = it }, label = { Text("Phiên bản (vd 1.7.10, 1.21.1)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("vanilla", "fabric", "quilt").forEach {
                FilterChip(loader == it, { loader = it }, label = { Text(it) })
            }
        }
        OutlinedTextField(cfKey, { cfKey = it }, label = { Text("CurseForge API key (tuỳ chọn)") },
            singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedButton({ picker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
            Text("Cài Modpack (.mrpack / .zip)")
        }
        Button(
            onClick = {
                scope.launch(Dispatchers.IO) {
                    busy = true
                    status = "Đang tải $version..."
                    val java = NovaCore.installVersion(version, root)
                    if (java < 0) { status = "Lỗi tải, xem log"; busy = false; return@launch }
                    var id = version
                    if (loader != "vanilla") {
                        val r = NovaCore.installLoader(version, loader, root)
                        if (r.startsWith("ERR")) { status = r; busy = false; return@launch }
                        id = r.substringBefore("|")
                    }
                    status = "Đang chạy"
                    val args = NovaCore.jvmArgs(java, ramMb()).split("\n")
                    withContext(Dispatchers.Main) {
                        GameLauncher.launch(ctx, root, id, java, args) { logs.add(it) }
                    }
                    busy = false
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth().height(80.dp)
        ) { Text("PLAY", fontSize = 28.sp) }
        Text("Trạng thái: $status", color = Color.LightGray)
        LazyColumn(Modifier.fillMaxWidth().weight(1f).background(Color.Black).padding(8.dp), state = listState) {
            items(logs) { Text(it, color = Color(0xFF7CFC9A), fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
        }
    }
}
