package com.horizonx.launcher

import android.content.Context

/**
 * Điểm nối với JVM bridge. Rust đã chuẩn bị: jar, libraries, assets, JVM args.
 * Phần còn lại phải đến từ PojavLauncher (LGPL-3.0): JRE ARM64 (assets/runtimes), LWJGL3 Android,
 * và lớp GL (gl4es/ANGLE/Zink) để Minecraft vẽ được trên Android. Hãy tích hợp JREUtils/
 * Tools của Pojav tại đây.
 */
object GameLauncher {
    fun launch(ctx: Context, root: String, version: String, javaMajor: Int, jvmArgs: List<String>, log: (String) -> Unit) {
        val cp = java.io.File(root, "libraries").walkTopDown().filter { it.extension == "jar" }
            .joinToString(":") { it.absolutePath } + ":$root/versions/$version/$version.jar"
        log("Java $javaMajor | ${jvmArgs.size} JVM args | classpath ${cp.length} ký tự")
        log("CHƯA CÓ JVM BRIDGE: gắn JREUtils.launchJavaVM(...) của Pojav vào GameLauncher.launch().")
    }
}
