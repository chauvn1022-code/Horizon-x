Đặt JRE ARM64 (java8/17/21 .tar.xz) từ PojavLauncher vào thư mục này.
