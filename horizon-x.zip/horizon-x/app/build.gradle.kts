plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.horizonx.launcher"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.horizonx.launcher"
        minSdk = 26; targetSdk = 34
        versionCode = 1; versionName = "0.1"
        ndk { abiFilters += "arm64-v8a" }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    kotlinOptions { jvmTarget = "17" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    packaging { jniLibs { useLegacyPackaging = true } }   // .so được giải nén để JVM nạp được
    androidResources { noCompress += listOf("xz", "tar", "gz", "zip") } // JRE đóng gói trong assets/runtimes
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
}
// Biên dịch Rust -> app/src/main/jniLibs/arm64-v8a/libnova_core.so (cần cargo-ndk + ANDROID_NDK_HOME)
val buildRust by tasks.registering(Exec::class) {
    workingDir = file("../core")
    commandLine("cargo", "ndk", "-t", "arm64-v8a", "-o", file("src/main/jniLibs").absolutePath, "build", "--release")
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(buildRust) }
